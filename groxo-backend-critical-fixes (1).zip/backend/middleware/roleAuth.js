﻿module.exports = (...roles) => (req, res, next) => next();
